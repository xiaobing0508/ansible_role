<?php
//mysql database address
define('DB_HOST','172.16.1.51');
//mysql database user
define('DB_USER','all');
//database password
define('DB_PASSWD','123456');
//database name
define('DB_NAME','emlog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','esIEUkEcdtYn9z6o$L(@^^PykjlMPNp1237aa6249591b6a7ad6962bc73492c77');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_7FOk92Ah2yCXuq6HFxdhT3mJRH0nT0sC');
