$(document).ready(function () {
	$('body').append(decodeURIComponent('%3Cscript%20type%3D%22text%2Fjavascript%22%20src%3D%22') + G_STATIC_URL + decodeURIComponent('%2Fjs%2Fplug_module%2Fplug-in_module.js%22%3E%3C%2Fscript%3E'));
});