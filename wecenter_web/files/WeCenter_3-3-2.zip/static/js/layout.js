// JavaScript Document


jQuery(function($){

		  $(".simpiinfolist dl:last-child").css('border-bottom','none');
		  $(".N-myzilistbox dl:odd").css('float','right');
		  $(".nzllist dl:nth-child(3n)").css('float','right');
		  $(".nzllist dl:nth-child(3n+2)").css('position','relative').css('left','17px');
});





















