CKEDITOR.plugins.setLang( 'html5video', 'ca', {
    button: "Insereix un vídeo HTML5",
    title: "Vídeo HTML5",
    infoLabel: "Informació del vídeo",
    allowed: "Extensions d'arxius permeses: MP4, WebM, Ogv",
    urlMissing: "Falta l'URL de la font de vídeo.",
    videoProperties: "Propietats de vídeo",
    upload: "Pujar",
    btnUpload: "Envia-lo al servidor",
    advanced: "Avançat",
    autoplay: "Reproducció automàtica?",
    yes: "Sí",
    no: "No",
    loop: "Bucle?",
    responsive: "Ample adaptatiu",
    controls: "Mostra els controls",
    poster: "Miniatura"
} );
