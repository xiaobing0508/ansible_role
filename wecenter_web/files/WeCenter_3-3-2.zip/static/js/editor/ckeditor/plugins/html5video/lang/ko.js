CKEDITOR.plugins.setLang( 'html5video', 'ko', {
    button: 'HTML5 비디오 추가하기',
    title: 'HTML5 비디오',
    infoLabel: '비디오 정보',
    allowed: '허용된 파일 확장자들: MP4, WebM, Ogv',
    urlMissing: '비디오 Url이 없습니다.',
    videoProperties: '비디오 속성',
    upload: '업로드',
    btnUpload: '서버로 전송',
    advanced: '고급',
    autoplay: '자동재생?',
    yes: '네',
    no: '아니오',
    loop: '무한반복?',
    responsive: '반응형 너비',
    controls: '컨트롤 보여주기',
    poster: '썸네일'
} );
