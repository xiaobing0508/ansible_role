CKEDITOR.plugins.setLang( 'html5video', 'bg', {
    button: 'Вмъква HTML5 видео',
    title: 'HTML5 видео',
    infoLabel: 'Видео',
    allowed: 'Допустими файлови разширения: MP4, WebM, Ogv',
    urlMissing: 'URL адресът на източника на видео липсва.',
    videoProperties: 'Свойства на видео',
    upload: 'Качване',
    btnUpload: 'Изпрати на сървъра',
    advanced: 'Разширено',
    autoplay: 'Автоматично изпълнение',
    yes: 'Да',
    no: 'Не',
    loop: 'Циклично изпълнение',
    responsive: 'Адаптивна ширина',
    controls: 'Показване на контролите',
    poster: 'URL миниатюра'
} );
